/*友情技术指导
  微信:Smart_Kage
*/
App({
    onLaunch: function() {},
    globalData: {
        userInfo: null
    }
});